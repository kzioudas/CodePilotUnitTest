package com.example.codepilotunittest.interfaces;

public interface TestStrategy {
    void generateTestCases(SrcElement srcElement);
}

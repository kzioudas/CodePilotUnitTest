package com.example.codepilotunittest.interfaces;

public interface SrcElement {
}

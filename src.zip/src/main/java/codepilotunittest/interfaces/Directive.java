package com.example.codepilotunittest.interfaces;

public interface Directive {
    boolean check();
}

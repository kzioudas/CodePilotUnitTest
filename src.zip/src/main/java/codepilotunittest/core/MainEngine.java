package com.example.codepilotunittest.core;
import java.nio.file.DirectoryStream;
import java.nio.file.Files;
import java.nio.file.Path;
import parser.factory.Parser;

public class MainEngine {
    public void generateTestCases() {
        // Implementation details
    }

    public void convertTestCaseToCode(TestCase testCase) {
        // Implementation details
    }
    public void treeFromParser(Path sourcePackagePath){
        ProjectParser pparser = new ProjectParser();

    }
}

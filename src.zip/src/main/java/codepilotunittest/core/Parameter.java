package com.example.codepilotunittest.core;

public class Parameter {
    private String name;
    private Class<?> type;

    public String getName() {
        return name;
    }

    public Class<?> getType() {
        return type;
    }
}

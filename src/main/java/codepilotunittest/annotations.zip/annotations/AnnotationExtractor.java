package codepilotunittest.annotations;

import com.example.codepilotunittest.parser.tree.LeafNode;
import java.util.List;

public class AnnotationExtractor {
    public static List<String> extractMethodAnnotations(LeafNode.Method method) {
        // Implementation to extract method annotations
    }

    public static List<String> extractClassAnnotations(LeafNode leafNode) {
        // Implementation to extract class annotations
    }
}

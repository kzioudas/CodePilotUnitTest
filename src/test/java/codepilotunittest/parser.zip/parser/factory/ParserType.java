package com.example.codepilotunittest.parser.factory;

public enum ParserType
{
    JDT,
    JAVAPARSER
}
